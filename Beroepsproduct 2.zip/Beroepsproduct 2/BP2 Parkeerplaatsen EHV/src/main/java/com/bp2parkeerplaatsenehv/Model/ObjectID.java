package com.bp2parkeerplaatsenehv.Model;

public class ObjectID {
    private Integer objectId;

    public ObjectID(Integer objectId) {
        this.objectId = objectId;
    }

    public Integer getObjectId() {
        return objectId;
    }

    public void setObjectId(Integer objectId) {
        this.objectId = objectId;
    }
}