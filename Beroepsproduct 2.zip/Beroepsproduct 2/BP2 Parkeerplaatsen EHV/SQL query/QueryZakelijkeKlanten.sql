USE ReserveringsappEHV;
SELECT * FROM ZakelijkeKlanten;